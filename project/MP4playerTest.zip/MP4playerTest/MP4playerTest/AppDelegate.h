//
//  AppDelegate.h
//  MP4playerTest
//
//  Created by Franky on 2019/1/21.
//  Copyright © 2019年 kugou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

