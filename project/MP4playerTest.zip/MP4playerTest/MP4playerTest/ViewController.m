//
//  ViewController.m
//  MP4playerTest
//
//  Created by Franky on 2019/1/21.
//  Copyright © 2019年 kugou. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()
{
    NSString *videoPath;
    BOOL playing;
    AVPlayer *player;
    AVAssetReader *reader;
    AVAssetWriter *writer;
    AVAssetWriterInput* writerInput;
    AVURLAsset *asset;
    CALayer *playView;
    dispatch_queue_t playerQueue;
    CGRect showRect;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    hasConfig = [self configHardWareDecode];
//    AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
//
//    player = [AVPlayer playerWithPlayerItem:item];
//    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
//    playerLayer.frame = CGRectMake(0, 0, self.view.bounds.size.width, 500);
//    [self.view.layer addSublayer:playerLayer];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"1"]];
    imageView.frame = self.view.bounds;
    [self.view addSubview:imageView];
    
    UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
    CGPoint center= self.view.center;
    button.frame=CGRectMake(center.x - 60, self.view.bounds.size.height -50, 60, 30);
    [button setTitle:@"手机" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor blueColor];
    [button addTarget:self action:@selector(playOrStop) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton *button2=[UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame=CGRectMake(center.x + 60, self.view.bounds.size.height -50, 60, 30);
    [button2 setTitle:@"PC" forState:UIControlStateNormal];
    button2.backgroundColor = [UIColor blueColor];
    [button2 addTarget:self action:@selector(playOrStop2) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    showRect = self.view.bounds;
    playView = [[CALayer alloc] init];
    playView.frame = showRect;
    [self.view.layer addSublayer:playView];
    
    playerQueue = dispatch_queue_create("com.player.queue", NULL);
}

- (void)playOrStop2
{
    videoPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"temp2.mp4"];
    NSURL *fileUrl = [NSURL fileURLWithPath:videoPath];
    NSDictionary *options = @{AVURLAssetPreferPreciseDurationAndTimingKey : @YES};
    asset = [[AVURLAsset alloc] initWithURL:fileUrl options:options];
    [self start];
}

- (void)playOrStop
{
    videoPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"720.mp4"];
    NSURL *readerUrl = [NSURL fileURLWithPath:videoPath];
    NSDictionary *options = @{AVURLAssetPreferPreciseDurationAndTimingKey : @YES};
    asset = [[AVURLAsset alloc] initWithURL:readerUrl options:options];
    
//    NSString* path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"capture.mp4"];
//    [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
//    NSURL* writeUrl = [NSURL fileURLWithPath:path];
//    writer = [AVAssetWriter assetWriterWithURL:writeUrl fileType:AVFileTypeQuickTimeMovie error:nil];
//    NSDictionary* settings = [NSDictionary dictionaryWithObjectsAndKeys:
//                              AVVideoCodecTypeH264, AVVideoCodecKey,
//                              @(showRect.size.width), AVVideoWidthKey,
//                              @(showRect.size.height), AVVideoHeightKey,
//                              [NSDictionary dictionaryWithObjectsAndKeys:
//                               @YES, AVVideoAllowFrameReorderingKey, nil],
//                              AVVideoCompressionPropertiesKey,
//                              nil];
//    writerInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeVideo outputSettings:settings];
//    writerInput.expectsMediaDataInRealTime = YES;
//    if ([writer canAddInput:writerInput]) {
//        [writer addInput:writerInput];
//    }
    [self start];
}

- (void)start
{
    [asset loadValuesAsynchronouslyForKeys:@[@"tracks"] completionHandler:^{
        dispatch_async(self->playerQueue, ^{
            NSError *error = nil;
            if (AVKeyValueStatusLoaded != [self->asset statusOfValueForKey:@"tracks" error:&error]) {

            }
            AVAssetReader *reader = [AVAssetReader assetReaderWithAsset:self->asset error:&error];
            // 配置AVAssetReaderTrackOutput
            NSArray *videoTracks = [self->asset tracksWithMediaType:AVMediaTypeVideo];
            if (videoTracks.count > 0) {
                AVAssetTrack *videoTrack = videoTracks.firstObject;
                if (videoTrack.nominalFrameRate > 0) {
                    NSDictionary *outputSettings = @{(id) kCVPixelBufferPixelFormatTypeKey : @(kCVPixelFormatType_32BGRA)};
                    AVAssetReaderTrackOutput *videoTrackOutput = [AVAssetReaderTrackOutput assetReaderTrackOutputWithTrack:videoTrack outputSettings:outputSettings];
                    if ([reader canAddOutput:videoTrackOutput]) {
                        [reader addOutput:videoTrackOutput];
                    }
                    if ([reader startReading]) {
                        int i = 0;
                        while (reader.status == AVAssetReaderStatusReading) {
                            CMSampleBufferRef sampleBuffer = [videoTrackOutput copyNextSampleBuffer];
                            if(sampleBuffer) {
                                NSLog(@"帧数：%d", i);
                                i++;
                                CGImageRef imageRef = [self fixImageBuffer:sampleBuffer showRect:self->showRect];
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    self->playView.contents = (__bridge id _Nullable)(imageRef);
                                    if (imageRef) {
                                        CGImageRelease(imageRef);
                                    }
                                });
                                CMSampleBufferInvalidate(sampleBuffer);
                                CFRelease(sampleBuffer);
                                usleep(30*1000);
                            } else {
                                break;
                            }
                        }
                        if (reader.status != AVAssetReaderStatusReading) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                self->playView.contents = nil;
                            });
                        }
                    }
                }
            }
        });
    }];
}

CGColorSpaceRef FACGColorSpaceGetDeviceRGB()
{
    static CGColorSpaceRef space;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        space = CGColorSpaceCreateDeviceRGB();
    });
    return space;
}

- (void)transImageBuffer:(CMSampleBufferRef)sampleBuffer
{
    if (CMSampleBufferDataIsReady(sampleBuffer))
    {
        if (writer.status == AVAssetWriterStatusUnknown)
        {
            CMTime startTime = CMSampleBufferGetPresentationTimeStamp(sampleBuffer);
            [writer startWriting];
            [writer startSessionAtSourceTime:startTime];
        }
        if (writer.status == AVAssetWriterStatusFailed)
        {
            NSLog(@"writer error %@", writer.error.localizedDescription);
        }
        if (writerInput.readyForMoreMediaData == YES)
        {
            [writerInput appendSampleBuffer:sampleBuffer];
        }
    }
}

- (CGImageRef)fixImageBuffer:(CMSampleBufferRef)sampleBuffer showRect:(CGRect)showRect
{
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    CVPixelBufferLockBaseAddress(imageBuffer, 0);
    void *baseAddress = CVPixelBufferGetBaseAddress(imageBuffer);
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
    CGFloat width = CVPixelBufferGetWidth(imageBuffer);
    CGFloat height = CVPixelBufferGetHeight(imageBuffer);
    
    CGFloat newHeight = height/2;
    CGFloat newWidth = showRect.size.width*newHeight/showRect.size.height;
    size_t leftMargin = (width - newWidth)/2;
    
    size_t totalByte = bytesPerRow * height/2;
    Byte *alphaData = baseAddress + totalByte;
    Byte *imageData = (uint8_t *)malloc(totalByte);
    memcpy(imageData, baseAddress, totalByte);
    
    for (int i = 3; i < totalByte; i = i +4) {
        imageData[i] = alphaData[i - 1];
    }
    
    Byte *showData = imageData + leftMargin * 4;
    
    CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Host | kCGImageAlphaPremultipliedFirst;
    CGContextRef context = CGBitmapContextCreate(showData, newWidth, newHeight, 8, bytesPerRow, FACGColorSpaceGetDeviceRGB(), bitmapInfo);
    
    CVPixelBufferUnlockBaseAddress(imageBuffer, 0);
    
    CGImageRef imageRef = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    free(imageData);
    
    return imageRef;
}

//- (void)reencodeComposition:(AVComposition *)composition toMP4File:(NSURL *)mp4FileURL withCompletionHandler:(void (^)(void))handler
//{
//    self.status = EncoderStatusEncoding;
//    
//    /*
//     Create the asset writer to write the file on disk
//     */
//    
//    NSError *error = nil;
//    if([[NSFileManager defaultManager] fileExistsAtPath:mp4FileURL.path isDirectory:nil])
//    {
//        if(![[NSFileManager defaultManager] removeItemAtPath:mp4FileURL.path error:&error])
//        {
//            [self failWithError:error withCompletionHandler:handler];
//            return;
//        }
//    }
//    
//    self.assetWriter = [[AVAssetWriter alloc] initWithURL:mp4FileURL fileType:AVFileTypeMPEG4 error:&error];
//    
//    if(self.assetWriter)
//    {
//        /*
//         Get the audio and video track of the composition
//         */
//        AVAssetTrack *videoAssetTrack = [composition tracksWithMediaType:AVMediaTypeVideo].firstObject;
//        AVAssetTrack *audioAssetTrack = [composition tracksWithMediaType:AVMediaTypeAudio].firstObject;
//        
//        NSDictionary *videoSettings = @{AVVideoCodecKey:AVVideoCodecH264, AVVideoWidthKey:@(self.imageWidth), AVVideoHeightKey:@(self.imageHeight)};
//        
//        /*
//         Add an input to be able to write the video in the file
//         */
//        AVAssetWriterInput* videoWriterInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeVideo outputSettings:videoSettings];
//        videoWriterInput.expectsMediaDataInRealTime = YES;
//        
//        if([self.assetWriter canAddInput:videoWriterInput])
//        {
//            [self.assetWriter addInput:videoWriterInput];
//            
//            /*
//             Add an input to be able to write the audio in the file
//             */
//            // Use this only if you know the format
//            //            CMFormatDescriptionRef audio_fmt_desc_ = nil;
//            //
//            //            AudioStreamBasicDescription audioFormat;
//            //            bzero(&audioFormat, sizeof(audioFormat));
//            //            audioFormat.mSampleRate = 44100;
//            //            audioFormat.mFormatID   = kAudioFormatMPEG4AAC;
//            //            audioFormat.mFramesPerPacket = 1024;
//            //            audioFormat.mChannelsPerFrame = 2;
//            //            int bytes_per_sample = sizeof(float);
//            //            audioFormat.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
//            //
//            //            audioFormat.mBitsPerChannel = bytes_per_sample * 8;
//            //            audioFormat.mBytesPerPacket = bytes_per_sample * 2;
//            //            audioFormat.mBytesPerFrame = bytes_per_sample * 2;
//            //
//            //            CMAudioFormatDescriptionCreate(kCFAllocatorDefault,&audioFormat,0,NULL,0,NULL,NULL,&audio_fmt_desc_);
//            //
//            //             AVAssetWriterInput* audioWriterInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeAudio outputSettings:nil sourceFormatHint:audio_fmt_desc_];
//            //
//            //            AVAssetWriterInput* audioWriterInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeAudio outputSettings:nil sourceFormatHint:((__bridge CMAudioFormatDescriptionRef)audioAssetTrack.formatDescriptions.firstObject)];
//            
//            audioWriterInput.expectsMediaDataInRealTime = YES;
//            
//            if([self.assetWriter canAddInput:audioWriterInput])
//            {
//                [self.assetWriter addInput:audioWriterInput];
//                [self.assetWriter startWriting];
//                [self.assetWriter startSessionAtSourceTime:kCMTimeZero];
//                
//                /*
//                 Create the asset reader to read the mp4 files on the disk
//                 */
//                AVAssetReader *assetReader = [[AVAssetReader alloc] initWithAsset:composition error:&error];
//                NSDictionary *videoOptions = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:kCVPixelFormatType_32BGRA] forKey:(id)kCVPixelBufferPixelFormatTypeKey];
//                
//                /*
//                 Add an output to be able to retrieve the video in the files
//                 */
//                AVAssetReaderTrackOutput *videoAssetTrackOutput = [[AVAssetReaderTrackOutput alloc] initWithTrack:videoAssetTrack outputSettings:videoOptions];
//                videoAssetTrackOutput.alwaysCopiesSampleData = NO;
//                
//                if([assetReader canAddOutput:videoAssetTrackOutput])
//                {
//                    [assetReader addOutput:videoAssetTrackOutput];
//                    /*
//                     Add an output to be able to retrieve the video in the files
//                     */
//                    AVAssetReaderTrackOutput *audioAssetTrackOutput = [[AVAssetReaderTrackOutput alloc] initWithTrack:audioAssetTrack outputSettings:nil];
//                    videoAssetTrackOutput.alwaysCopiesSampleData = NO;
//                    
//                    if([assetReader canAddOutput:audioAssetTrackOutput])
//                    {
//                        [assetReader addOutput:audioAssetTrackOutput];
//                        
//                        [assetReader startReading];
//                        
//                        /*
//                         Read the mp4 files until the end and copy them in the output file
//                         */
//                        dispatch_group_t encodingGroup = dispatch_group_create();
//                        
//                        dispatch_group_enter(encodingGroup);
//                        [audioWriterInput requestMediaDataWhenReadyOnQueue:self.encodingQueue usingBlock:^{
//                            while ([audioWriterInput isReadyForMoreMediaData])
//                            {
//                                CMSampleBufferRef nextSampleBuffer = [audioAssetTrackOutput copyNextSampleBuffer];
//                                
//                                if (nextSampleBuffer)
//                                {
//                                    [audioWriterInput appendSampleBuffer:nextSampleBuffer];
//                                    CFRelease(nextSampleBuffer);
//                                }
//                                else
//                                {
//                                    [audioWriterInput markAsFinished];
//                                    dispatch_group_leave(encodingGroup);
//                                    break;
//                                }
//                            }
//                        }];
//                        
//                        dispatch_group_enter(encodingGroup);
//                        [videoWriterInput requestMediaDataWhenReadyOnQueue:self.encodingQueue usingBlock:^{
//                            while ([videoWriterInput isReadyForMoreMediaData])
//                            {
//                                CMSampleBufferRef nextSampleBuffer = [videoAssetTrackOutput copyNextSampleBuffer];
//                                
//                                if (nextSampleBuffer)
//                                {
//                                    [videoWriterInput appendSampleBuffer:nextSampleBuffer];
//                                    CFRelease(nextSampleBuffer);
//                                }
//                                else
//                                {
//                                    [videoWriterInput markAsFinished];
//                                    dispatch_group_leave(encodingGroup);
//                                    break;
//                                }
//                            }
//                        }];
//                        
//                        dispatch_group_wait(encodingGroup, DISPATCH_TIME_FOREVER);
//                        
//                    } else [self failWithError:error withCompletionHandler:handler];
//                } else [self failWithError:error withCompletionHandler:handler];
//            } else [self failWithError:error withCompletionHandler:handler];
//        } else [self failWithError:error withCompletionHandler:handler];
//        
//        __weak Encoder *weakself = self;
//        [self.assetWriter finishWritingWithCompletionHandler:^{
//            self.status = EncoderStatusCompleted;
//            handler();
//            weakself.assetWriter = nil;
//            self.encodingQueue = nil;
//        }];
//    }
//    else [self failWithError:error withCompletionHandler:handler];
//}

@end
