//
//  ViewController.h
//  MP4playerTest
//
//  Created by Franky on 2019/1/21.
//  Copyright © 2019年 kugou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

